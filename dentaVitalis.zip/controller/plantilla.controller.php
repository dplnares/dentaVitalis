<?php

class ControllerPlantilla
{
  static public function ctrPlantilla()
  {
    include "view/plantilla.php";
  }
}