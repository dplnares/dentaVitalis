<?php

class ControllerFunciones
{
  
}